askfm-python:
==============

A python (3.x) requests + lxml based client side library for Ask.fm.

FILES:
------

askfm.py: The library containing functions.

pull_user.py: Finds everything by a given username, and outputs it into a JSON string. 


LEGACY:
-------

pull_handles.py <username>: Finds every user who has liked any of your posts.

pull_answers.py <username>: Finds answers from a given username.

