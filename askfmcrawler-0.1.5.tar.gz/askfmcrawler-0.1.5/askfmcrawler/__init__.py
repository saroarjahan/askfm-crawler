from askfmcrawler.entities import Article, User
from askfmcrawler.crawl import Crawler
